require('./dirPagination');
module.exports = 'angularUtils.directives.dirPagination';
