/* global angular */
'use strict';

angular.module('exampleApp', ['angular-click-outside']);