##Installation

Be sure to run the following command from within this example folder for the example to run

```
    bower install angular
```